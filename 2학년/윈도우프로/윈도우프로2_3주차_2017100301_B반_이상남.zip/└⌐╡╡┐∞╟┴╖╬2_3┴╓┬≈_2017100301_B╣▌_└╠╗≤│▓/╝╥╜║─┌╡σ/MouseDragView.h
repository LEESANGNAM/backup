﻿
// MouseDragView.h: CMouseDragView 클래스의 인터페이스
//

#pragma once


class CMouseDragView : public CView
{
protected: // serialization에서만 만들어집니다.
	CMouseDragView() noexcept;
	DECLARE_DYNCREATE(CMouseDragView)

// 특성입니다.
public:
	CMouseDragDoc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual void OnDraw(CDC* pDC);  // 이 뷰를 그리기 위해 재정의되었습니다.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 구현입니다.
public:
	virtual ~CMouseDragView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	CPoint m_Point;
	CString ms_Message;
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
//	int ms_Sx;
	int mn_Sx;
	int mn_Sy;
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	bool mb_Flag;
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
};

#ifndef _DEBUG  // MouseDragView.cpp의 디버그 버전
inline CMouseDragDoc* CMouseDragView::GetDocument() const
   { return reinterpret_cast<CMouseDragDoc*>(m_pDocument); }
#endif

