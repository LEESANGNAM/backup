﻿
// MyKeyInputView.cpp: CMyKeyInputView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "MyKeyInput.h"
#endif

#include "MyKeyInputDoc.h"
#include "MyKeyInputView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMyKeyInputView

IMPLEMENT_DYNCREATE(CMyKeyInputView, CView)

BEGIN_MESSAGE_MAP(CMyKeyInputView, CView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMyKeyInputView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_CHAR()
	ON_WM_LBUTTONDOWN()
	ON_WM_SIZE()
END_MESSAGE_MAP()

// CMyKeyInputView 생성/소멸

CMyKeyInputView::CMyKeyInputView() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

	m_nSx = 0;
	m_nSy = 0;
	m_strDisplay = _T("");
	//  m = 0;
	m_nXMAX = 0;
	m_nYMAX = 0;
}

CMyKeyInputView::~CMyKeyInputView()
{
}

BOOL CMyKeyInputView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CMyKeyInputView 그리기

void CMyKeyInputView::OnDraw(CDC* pDC)
{
	CMyKeyInputDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.

	pDC->TextOutW(m_nSx, m_nSy, m_strDisplay);

}


// CMyKeyInputView 인쇄


void CMyKeyInputView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMyKeyInputView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CMyKeyInputView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CMyKeyInputView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}

void CMyKeyInputView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CMyKeyInputView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMyKeyInputView 진단

#ifdef _DEBUG
void CMyKeyInputView::AssertValid() const
{
	CView::AssertValid();
}

void CMyKeyInputView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMyKeyInputDoc* CMyKeyInputView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMyKeyInputDoc)));
	return (CMyKeyInputDoc*)m_pDocument;
}
#endif //_DEBUG


// CMyKeyInputView 메시지 처리기


void CMyKeyInputView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	/*CString str;
	str.Format(_T("KeyDown : %x"), nChar);
	MessageBox(str);*/

	switch(nChar) {
	case VK_LEFT: m_nSx--;	break;
	case VK_RIGHT: m_nSx++; break;
	case VK_UP: m_nSy--; break;
	case VK_DOWN: m_nSy++; break;
	case VK_HOME: m_nSy--; m_nSx--; break;
	case VK_PRIOR: m_nSy--; m_nSx++; break;
	case VK_END:m_nSy++; m_nSx--; break;
	case VK_NEXT:	m_nSy++; m_nSx++; break;
	}
	CSize cs = GetDC()->GetTextExtent(m_strDisplay);
	if (m_nSx < 0) m_nSx = 0;
	if (m_nSy < 0)	m_nSy = 0;
	if (m_nSx >= m_nXMAX - cs.cx) {
		m_nSx = m_nXMAX - cs.cx;
		MessageBox(_T("더이상 우측진행 불가"));
	}
	if (m_nSy >= m_nYMAX - cs.cy) {
		m_nSy = m_nYMAX - cs.cy;
		MessageBox(_T("더이상 진행 불가"));
	}
	Invalidate();
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CMyKeyInputView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	/*CString str;
	str.Format(_T("OnChar : %x"), nChar);
	MessageBox(str);*/
	//PU = 21 PD = 22 End = 23 Home = 24 위 = 25 좌 26 아래 27 우 28
	int ind;
	if (nChar == VK_BACK) {
		ind = m_strDisplay.GetLength() - 1;
			m_strDisplay.Delete(ind, 1);
	}
	else	
	m_strDisplay.Format(_T("%s%c"),m_strDisplay,nChar);
	Invalidate();

	CView::OnChar(nChar, nRepCnt, nFlags);
}


void CMyKeyInputView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	m_nSx = point.x;
	m_nSy = point.y;

	CView::OnLButtonDown(nFlags, point);
}


void CMyKeyInputView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);
	m_nXMAX = cx;
	m_nYMAX = cy;
	// TODO: 여기에 메시지 처리기 코드를 추가합니다.
}
